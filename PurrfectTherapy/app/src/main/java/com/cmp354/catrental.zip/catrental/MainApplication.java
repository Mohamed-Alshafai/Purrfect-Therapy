package com.cmp354.catrental;

import android.app.Application;
import android.content.Intent;
import android.util.Log;

import androidx.core.content.ContextCompat;

public class MainApplication extends Application {
    private final String TAG = "MainApplication";
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Application Started");
    }
}
